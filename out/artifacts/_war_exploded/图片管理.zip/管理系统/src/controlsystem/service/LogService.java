package controlsystem.service;

import controlsystem.entity.T_Log;

public interface LogService {

    void addLog(T_Log t_log);
}
