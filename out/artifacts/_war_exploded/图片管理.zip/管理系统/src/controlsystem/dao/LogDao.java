package controlsystem.dao;

import controlsystem.entity.T_Log;

public interface LogDao {

    void insert(T_Log t_log);
}
